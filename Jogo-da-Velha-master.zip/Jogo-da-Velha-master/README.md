Portuguese:
# Jogo da Velha em .NET
Jogo da Velha desenvolvido em WinForms e .NET
Esta aplicação utiliza a abordagem de divisão e conquista para calcular as possiblidades do tabuleiro do jogo.
Tem o modo CO-OP, PC X PC e Player X PC

English:
# Tic-Tac-toe in .NET
Tic Tac Toe developed in WinForms and .NET
This application uses the division and conquest approach to calculate the possibilities of the game board.
It has CO-OP, PC X PC and Player X PC mode

## Prints da APP:

![j](https://user-images.githubusercontent.com/52250904/111877026-15d48300-8980-11eb-9899-352558f38845.PNG)
![2](https://user-images.githubusercontent.com/52250904/111877029-1836dd00-8980-11eb-88f3-5cc2f6444f20.PNG)

![Capturar](https://user-images.githubusercontent.com/52250904/111877030-1a00a080-8980-11eb-95dd-dfb101083300.PNG)



KeyWords: POO, WinForms, C#, .NET

Developed By: César Henrique Alves Oncala
