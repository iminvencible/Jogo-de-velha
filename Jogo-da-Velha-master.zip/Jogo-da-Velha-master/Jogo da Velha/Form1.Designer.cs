﻿namespace Jogo_da_Velha
{
    partial class Jogo_da_Velha
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.zero_zero = new System.Windows.Forms.Button();
            this.Normal = new System.Windows.Forms.RadioButton();
            this.zero_um = new System.Windows.Forms.Button();
            this.zero_dois = new System.Windows.Forms.Button();
            this.um_zero = new System.Windows.Forms.Button();
            this.um_um = new System.Windows.Forms.Button();
            this.um_dois = new System.Windows.Forms.Button();
            this.dois_zero = new System.Windows.Forms.Button();
            this.dois_um = new System.Windows.Forms.Button();
            this.dois_dois = new System.Windows.Forms.Button();
            this.Automatico = new System.Windows.Forms.RadioButton();
            this.PCxPC = new System.Windows.Forms.RadioButton();
            this.JogadorxPC = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.Reiniciar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblNomeCriador = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtBoxHUD = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // zero_zero
            // 
            this.zero_zero.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero_zero.Location = new System.Drawing.Point(15, 46);
            this.zero_zero.Name = "zero_zero";
            this.zero_zero.Size = new System.Drawing.Size(105, 82);
            this.zero_zero.TabIndex = 0;
            this.zero_zero.UseVisualStyleBackColor = true;
            this.zero_zero.Click += new System.EventHandler(this.button1_Click);
            // 
            // Normal
            // 
            this.Normal.AutoSize = true;
            this.Normal.Checked = true;
            this.Normal.Location = new System.Drawing.Point(7, 23);
            this.Normal.Name = "Normal";
            this.Normal.Size = new System.Drawing.Size(58, 17);
            this.Normal.TabIndex = 11;
            this.Normal.TabStop = true;
            this.Normal.Text = "Normal";
            this.Normal.UseVisualStyleBackColor = true;
            // 
            // zero_um
            // 
            this.zero_um.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero_um.Location = new System.Drawing.Point(126, 46);
            this.zero_um.Name = "zero_um";
            this.zero_um.Size = new System.Drawing.Size(105, 82);
            this.zero_um.TabIndex = 12;
            this.zero_um.UseVisualStyleBackColor = true;
            this.zero_um.Click += new System.EventHandler(this.button2_Click);
            // 
            // zero_dois
            // 
            this.zero_dois.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero_dois.Location = new System.Drawing.Point(239, 46);
            this.zero_dois.Name = "zero_dois";
            this.zero_dois.Size = new System.Drawing.Size(105, 82);
            this.zero_dois.TabIndex = 13;
            this.zero_dois.UseVisualStyleBackColor = true;
            this.zero_dois.Click += new System.EventHandler(this.button3_Click);
            // 
            // um_zero
            // 
            this.um_zero.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.um_zero.Location = new System.Drawing.Point(15, 134);
            this.um_zero.Name = "um_zero";
            this.um_zero.Size = new System.Drawing.Size(105, 82);
            this.um_zero.TabIndex = 16;
            this.um_zero.UseVisualStyleBackColor = true;
            this.um_zero.Click += new System.EventHandler(this.button4_Click);
            // 
            // um_um
            // 
            this.um_um.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.um_um.Location = new System.Drawing.Point(126, 134);
            this.um_um.Name = "um_um";
            this.um_um.Size = new System.Drawing.Size(105, 82);
            this.um_um.TabIndex = 15;
            this.um_um.UseVisualStyleBackColor = true;
            this.um_um.Click += new System.EventHandler(this.button5_Click);
            // 
            // um_dois
            // 
            this.um_dois.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.um_dois.Location = new System.Drawing.Point(239, 134);
            this.um_dois.Name = "um_dois";
            this.um_dois.Size = new System.Drawing.Size(105, 82);
            this.um_dois.TabIndex = 14;
            this.um_dois.UseVisualStyleBackColor = true;
            this.um_dois.Click += new System.EventHandler(this.button6_Click);
            // 
            // dois_zero
            // 
            this.dois_zero.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dois_zero.Location = new System.Drawing.Point(15, 222);
            this.dois_zero.Name = "dois_zero";
            this.dois_zero.Size = new System.Drawing.Size(105, 82);
            this.dois_zero.TabIndex = 19;
            this.dois_zero.UseVisualStyleBackColor = true;
            this.dois_zero.Click += new System.EventHandler(this.button7_Click);
            // 
            // dois_um
            // 
            this.dois_um.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dois_um.Location = new System.Drawing.Point(126, 222);
            this.dois_um.Name = "dois_um";
            this.dois_um.Size = new System.Drawing.Size(105, 82);
            this.dois_um.TabIndex = 18;
            this.dois_um.UseVisualStyleBackColor = true;
            this.dois_um.Click += new System.EventHandler(this.button8_Click);
            // 
            // dois_dois
            // 
            this.dois_dois.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dois_dois.Location = new System.Drawing.Point(239, 222);
            this.dois_dois.Name = "dois_dois";
            this.dois_dois.Size = new System.Drawing.Size(105, 82);
            this.dois_dois.TabIndex = 17;
            this.dois_dois.UseVisualStyleBackColor = true;
            this.dois_dois.Click += new System.EventHandler(this.button9_Click);
            // 
            // Automatico
            // 
            this.Automatico.AutoSize = true;
            this.Automatico.Location = new System.Drawing.Point(7, 46);
            this.Automatico.Name = "Automatico";
            this.Automatico.Size = new System.Drawing.Size(78, 17);
            this.Automatico.TabIndex = 20;
            this.Automatico.Text = "Automatico";
            this.Automatico.UseVisualStyleBackColor = true;
            this.Automatico.Click += new System.EventHandler(this.radioButton2_Click);
            // 
            // PCxPC
            // 
            this.PCxPC.AutoSize = true;
            this.PCxPC.Location = new System.Drawing.Point(7, 69);
            this.PCxPC.Name = "PCxPC";
            this.PCxPC.Size = new System.Drawing.Size(73, 17);
            this.PCxPC.TabIndex = 21;
            this.PCxPC.TabStop = true;
            this.PCxPC.Text = "PC VS PC";
            this.PCxPC.UseVisualStyleBackColor = true;
            this.PCxPC.Visible = false;
            // 
            // JogadorxPC
            // 
            this.JogadorxPC.AutoSize = true;
            this.JogadorxPC.Location = new System.Drawing.Point(86, 69);
            this.JogadorxPC.Name = "JogadorxPC";
            this.JogadorxPC.Size = new System.Drawing.Size(97, 17);
            this.JogadorxPC.TabIndex = 22;
            this.JogadorxPC.TabStop = true;
            this.JogadorxPC.Text = "Jogador VS PC";
            this.JogadorxPC.UseVisualStyleBackColor = true;
            this.JogadorxPC.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(269, 322);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 58);
            this.button1.TabIndex = 23;
            this.button1.Text = "Start";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Reiniciar
            // 
            this.Reiniciar.Location = new System.Drawing.Point(264, 69);
            this.Reiniciar.Name = "Reiniciar";
            this.Reiniciar.Size = new System.Drawing.Size(75, 23);
            this.Reiniciar.TabIndex = 24;
            this.Reiniciar.Text = "Limpar";
            this.Reiniciar.UseVisualStyleBackColor = true;
            this.Reiniciar.Click += new System.EventHandler(this.Reiniciar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.groupBox1.Controls.Add(this.Normal);
            this.groupBox1.Controls.Add(this.Reiniciar);
            this.groupBox1.Controls.Add(this.Automatico);
            this.groupBox1.Controls.Add(this.PCxPC);
            this.groupBox1.Controls.Add(this.JogadorxPC);
            this.groupBox1.Location = new System.Drawing.Point(5, 315);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(349, 100);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Opções de jogo";
            // 
            // lblNomeCriador
            // 
            this.lblNomeCriador.AutoSize = true;
            this.lblNomeCriador.Location = new System.Drawing.Point(105, 473);
            this.lblNomeCriador.Name = "lblNomeCriador";
            this.lblNomeCriador.Size = new System.Drawing.Size(146, 13);
            this.lblNomeCriador.TabIndex = 27;
            this.lblNomeCriador.Text = "César Henrique Alves Oncala";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.groupBox2.Location = new System.Drawing.Point(5, 36);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(349, 273);
            this.groupBox2.TabIndex = 28;
            this.groupBox2.TabStop = false;
            // 
            // txtBoxHUD
            // 
            this.txtBoxHUD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtBoxHUD.Enabled = false;
            this.txtBoxHUD.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxHUD.ForeColor = System.Drawing.Color.Lime;
            this.txtBoxHUD.Location = new System.Drawing.Point(15, 4);
            this.txtBoxHUD.Multiline = true;
            this.txtBoxHUD.Name = "txtBoxHUD";
            this.txtBoxHUD.Size = new System.Drawing.Size(329, 30);
            this.txtBoxHUD.TabIndex = 29;
            // 
            // Jogo_da_Velha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(364, 521);
            this.Controls.Add(this.lblNomeCriador);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dois_zero);
            this.Controls.Add(this.dois_um);
            this.Controls.Add(this.dois_dois);
            this.Controls.Add(this.um_zero);
            this.Controls.Add(this.um_um);
            this.Controls.Add(this.um_dois);
            this.Controls.Add(this.zero_dois);
            this.Controls.Add(this.zero_um);
            this.Controls.Add(this.zero_zero);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.txtBoxHUD);
            this.Name = "Jogo_da_Velha";
            this.Text = "Jogo_da_Velha";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RadioButton Normal;
        private System.Windows.Forms.RadioButton Automatico;
        private System.Windows.Forms.RadioButton PCxPC;
        private System.Windows.Forms.RadioButton JogadorxPC;
        public System.Windows.Forms.Button zero_zero;
        public System.Windows.Forms.Button zero_um;
        public System.Windows.Forms.Button zero_dois;
        public System.Windows.Forms.Button um_zero;
        public System.Windows.Forms.Button um_um;
        public System.Windows.Forms.Button um_dois;
        public System.Windows.Forms.Button dois_zero;
        public System.Windows.Forms.Button dois_um;
        public System.Windows.Forms.Button dois_dois;
        public System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Reiniciar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblNomeCriador;
        private System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.TextBox txtBoxHUD;
    }
}

